/**
 * 
 */
package Games;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * @author Justin Yeung
 *
 */
public class Snap {

	private int playerTurn = 1;
	private Deck player1Deck;
	private Deck player2Deck;
	private ArrayList<Card> pile;
	
	public final int PLAYER_1 = 1;
	public final int PLAYER_2 = 2;
	
	public Snap()
	{
		player1Deck = new Deck(true);
		player2Deck = new Deck(true);
		
		for (int i = 0; i < 26; i++)
		{
			player1Deck.drawCard();
			player2Deck.drawCard(); // Remove 26 cards from each deck.
		}
		
		pile = new ArrayList<Card>();
		setupPlayerDecks();
	}
	
	private void setupPlayerDecks()
	{
		player1Deck.shuffle();
		player2Deck.shuffle();
	}
	
	private void pickupPile(int player)
	{
		for (Card cards : pile)
		{
			if (player == PLAYER_1)
			{
				player1Deck.placeCard(cards);
			}
			else if (player == PLAYER_2)
			{
				player2Deck.placeCard(cards);
			}
		}
		
		switch (player)
		{
		case PLAYER_1:
			player1Deck.shuffle();
			
		case PLAYER_2:
			player2Deck.shuffle();
		}
		pile.clear();
	}
	
	private boolean checkSnap()
	{
		if (pile.size() == 0)
		{
			System.out.println("Cannot snap when there are no cards in the pile");
			return false;
		}
		
		Card lastCard = pile.get(pile.size() - 1);
		Card last2Card = pile.get(pile.size() - 2);
		if (lastCard.getValue() == last2Card.getValue())
		{
			return true;
		}
		return false;
	}
	
	public boolean snap(int player)
	{
		if (player == PLAYER_1)
		{
			playerTurn = 2;
			if (checkSnap() == true)
			{
				pickupPile(PLAYER_1);
				return true;
			}
			else
			{
				pickupPile(PLAYER_2);
			}
			
		}
		
		else if (player == PLAYER_2)
		{
			playerTurn = 1;
			if (checkSnap() == true)
			{
				pickupPile(PLAYER_2);
				return true;
			}
			else
			{
				pickupPile(PLAYER_1);
			}
			
		}
		return false;
	}
	
	public Card drawCard(int player)
	{
		Card playerCard;
		if (player == PLAYER_1)
		{
			playerCard = player1Deck.drawCard();
			pile.add(playerCard);
			playerTurn = 2;
			return playerCard;
		}
		else if (player == PLAYER_2)
		{
			playerCard = player2Deck.drawCard();
			pile.add(playerCard);
			playerTurn = 1;
			return playerCard;
		}
		
		return null;
	}
	
	public boolean hasGameFinished()
	{
		if (player1Deck.hasCardsRemaining() == false)
		{
			return true;
		}
		else if (player2Deck.hasCardsRemaining() == false)
		{
			return true;
		}
		
		return false;
	}
	
	public boolean isWinner(int player)
	{
		switch (player)
		{
		
		case PLAYER_1:
			return player1Deck.hasCardsRemaining();
			
		case PLAYER_2:
			return player2Deck.hasCardsRemaining();
		}
		
		return false;
	}
	
	public int getPlayerTurn()
	{
		return playerTurn;
	}
	
	public int getPlayerCardsRemaining(int player)
	{
		switch (player)
		{
		case PLAYER_1:
			return player1Deck.getDeckSize();
			
		case PLAYER_2:
			return player2Deck.getDeckSize();
		}
		
		return 0;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Snap snap = new Snap();
		Scanner scan = new Scanner(System.in);
		int input = 0;
		int playerTurn = snap.getPlayerTurn();
		Card[] playerCard = new Card[3];
		Card player1Card;
		Card player2Card;
		boolean snapSuccessful;
		boolean keepPlaying = true;
		
		while (keepPlaying == true)
		{
			switch (snap.getPlayerTurn())
			{
			
			case 1:
			{
				System.out.println("Player 1's cards remaining: " + snap.getPlayerCardsRemaining(1));
				System.out.print("Player 1 turn(1 = draw, 2 = snap): ");
				input = scan.nextInt();
				
				if (input == 1)
				{
					player1Card = snap.drawCard(1);
					System.out.println("You have drawn: " + player1Card.toString());
				}
				else if (input == 2)
				{
					
					snapSuccessful = snap.snap(1);
					if (snapSuccessful == true)
					{
						System.out.println("Snapped! The pile of cards now go to player 1's deck.");
					}
					else
					{
						System.out.println("Unsuccessful snap, the pile of cards now go to player 2's deck.");
					}
				}
			}
			
			case 2:
			{
				System.out.println("Player 2's cards remaining: " + snap.getPlayerCardsRemaining(2));
				System.out.print("Player 2 turn(1 = draw, 2 = snap): ");
				input = scan.nextInt();
				
				if (input == 1)
				{
					player2Card = snap.drawCard(2);
					System.out.println("You have drawn: " + player2Card.toString());
				}
				else if (input == 2)
				{
					snapSuccessful = snap.snap(2);
					if (snapSuccessful == true)
					{
						System.out.println("Snapped! The pile of cards now go to player 2's deck.");
					}
					else
					{
						System.out.println("Unsuccessful snap, the pile of cards now go to player 1's deck.");
					}
				}
			}
			}
			
			if (snap.hasGameFinished() == true)
			{
				keepPlaying = false;
			}
		}
		
		if (snap.isWinner(1) == true)
		{
			System.out.println("Player 1 has won the game with " + snap.getPlayerCardsRemaining(1) + " cards remaining.");
		}
		else if (snap.isWinner(2) == true)
		{
			System.out.println("Player 2 has won the game with " + snap.getPlayerCardsRemaining(2) + " cards remaining.");
		}
		else
		{
			System.out.println("The game has ended in a draw with both players ran out of cards.");
		}
	}
}
